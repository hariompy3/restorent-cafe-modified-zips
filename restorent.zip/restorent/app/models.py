# restaurant/models.py
from django.contrib.auth.models import AbstractUser
from django.db import models

class CustomUser(AbstractUser):
    ROLE_CHOICES = (
        ('customer', 'Customer'),
        ('worker', 'Worker'),
        ('owner', 'Owner'),
    )
    role = models.CharField(max_length=10, choices=ROLE_CHOICES, default='customer')
    email = models.EmailField(unique=True)
    phone_number = models.CharField(max_length=15, blank=True, null=True)

    def __str__(self):
        return f"{self.username} - {self.get_role_display()}"

class Customer(models.Model):
    user = models.OneToOneField(CustomUser, on_delete=models.CASCADE, related_name='customer_profile')
    address = models.TextField(blank=True, null=True)
    loyalty_points = models.IntegerField(default=0)
    game_points = models.IntegerField(default=0)

    def __str__(self):
        return f"Customer: {self.user.username}"

    def add_game_points(self, points):
        self.game_points += points
        self.save()

    def redeem_game_points(self, points):
        if self.game_points >= points:
            self.game_points -= points
            self.save()
            return True
        return False

class Worker(models.Model):
    user = models.OneToOneField(CustomUser, on_delete=models.CASCADE, related_name='worker_profile')
    employee_id = models.CharField(max_length=20, unique=True)
    position = models.CharField(max_length=50)
    hire_date = models.DateField()

    def __str__(self):
        return f"Worker: {self.user.username} - {self.position}"

class Owner(models.Model):
    user = models.OneToOneField(CustomUser, on_delete=models.CASCADE, related_name='owner_profile')
    business_name = models.CharField(max_length=100)
    business_id = models.CharField(max_length=20, unique=True)
    establishment_date = models.DateField()

    def __str__(self):
        return f"Owner: {self.user.username} - {self.business_name}"

class Category(models.Model):
    name = models.CharField(max_length=100, unique=True)
    description = models.TextField(blank=True, null=True)

    def __str__(self):
        return self.name

class MenuItem(models.Model):
    name = models.CharField(max_length=200)
    description = models.TextField()
    price = models.DecimalField(max_digits=6, decimal_places=2)
    category = models.ForeignKey(Category, on_delete=models.SET_NULL, null=True, related_name='items')
    is_available = models.BooleanField(default=True)
    image = models.ImageField(upload_to='menu_items/', blank=True, null=True)
    discount = models.DecimalField(max_digits=5, decimal_places=2, default=0)  # New field

    def __str__(self):
        return self.name

    def discounted_price(self):
        return self.price - (self.price * (self.discount / 100))

class Order(models.Model):
    STATUS_CHOICES = (
        ('pending', 'Pending'),
        ('preparing', 'Preparing'),
        ('ready', 'Ready for Pickup'),
        ('delivered', 'Delivered'),
        ('cancelled', 'Cancelled'),
    )
    
    customer = models.ForeignKey(Customer, on_delete=models.CASCADE, related_name='orders')
    table_number = models.PositiveIntegerField(null=True, blank=True)
    status = models.CharField(max_length=20, choices=STATUS_CHOICES, default='pending')
    created_at = models.DateTimeField(auto_now_add=True)
    updated_at = models.DateTimeField(auto_now=True)
    applied_coupon = models.ForeignKey('Coupon', on_delete=models.SET_NULL, null=True, blank=True)
    total_amount = models.DecimalField(max_digits=8, decimal_places=2)

    def __str__(self):
        return f"Order {self.id} by {self.customer.user.username}"

class OrderItem(models.Model):
    order = models.ForeignKey(Order, on_delete=models.CASCADE, related_name='items')
    menu_item = models.ForeignKey(MenuItem, on_delete=models.CASCADE)
    quantity = models.PositiveIntegerField(default=1)
    subtotal = models.DecimalField(max_digits=8, decimal_places=2)

    def __str__(self):
        return f"{self.quantity}x {self.menu_item.name} in Order {self.order.id}"

class Table(models.Model):
    number = models.PositiveIntegerField(unique=True)
    capacity = models.PositiveIntegerField()
    is_available = models.BooleanField(default=True)

    def __str__(self):
        return f"Table {self.number} (Capacity: {self.capacity})"

class Reservation(models.Model):
    customer = models.ForeignKey(Customer, on_delete=models.CASCADE, related_name='reservations')
    table = models.ForeignKey(Table, on_delete=models.CASCADE, related_name='reservations')
    date = models.DateField()
    time = models.TimeField()
    party_size = models.PositiveIntegerField()
    status = models.CharField(max_length=20, choices=[('confirmed', 'Confirmed'), ('cancelled', 'Cancelled')], default='confirmed')

    def __str__(self):
        return f"Reservation for {self.customer.user.username} on {self.date} at {self.time}"
        
        
        
        
        
        
        # Add this to your existing models.py file

class Feedback(models.Model):
    customer = models.ForeignKey(Customer, on_delete=models.CASCADE, related_name='feedbacks')
    menu_item = models.ForeignKey(MenuItem, on_delete=models.CASCADE, related_name='feedbacks')
    rating = models.PositiveIntegerField(choices=[(i, i) for i in range(1, 6)])  # 1 to 5 stars
    comment = models.TextField(blank=True, null=True)
    created_at = models.DateTimeField(auto_now_add=True)

    class Meta:
        unique_together = ('customer', 'menu_item')  # Ensure one feedback per customer per item

    def __str__(self):
        return f"{self.customer.user.username}'s feedback on {self.menu_item.name}: {self.rating} stars"
        
        
        
        
        
        
# Add these imports at the top of your models.py file
from django.utils.crypto import get_random_string
from django.utils import timezone

# Add these new models to your existing models.py file

class GuessingGame(models.Model):
    customer = models.ForeignKey(Customer, on_delete=models.CASCADE, related_name='guessing_games')
    order = models.OneToOneField(Order, on_delete=models.CASCADE, related_name='guessing_game')
    is_played = models.BooleanField(default=False)
    created_at = models.DateTimeField(auto_now_add=True)

    class Meta:
        unique_together = ('customer', 'order')

    def __str__(self):
        return f"Game for Order {self.order.id} by {self.customer.user.username}"


class Coupon(models.Model):
    code = models.CharField(max_length=20, unique=True)
    customer = models.ForeignKey(Customer, on_delete=models.CASCADE, related_name='coupons')
    discount_percentage = models.IntegerField()
    is_used = models.BooleanField(default=False)
    expiry_date = models.DateTimeField()
    created_at = models.DateTimeField(auto_now_add=True)
    redeemed_game_points = models.PositiveIntegerField(null=True, blank=True)  # Updated field name

    def __str__(self):
        return f"Coupon {self.code} for {self.customer.user.username} ({self.discount_percentage}% off)"

    @classmethod
    def create_coupon(cls, customer, discount_percentage, redeemed_game_points=None):
        code = get_random_string(length=10)
        expiry_date = timezone.now() + timezone.timedelta(days=30)
        return cls.objects.create(
            code=code,
            customer=customer,
            discount_percentage=discount_percentage,
            expiry_date=expiry_date,
            redeemed_game_points=redeemed_game_points
        )




from django.core.validators import MinValueValidator
class PointRedemptionOption(models.Model):
    game_points_required = models.PositiveIntegerField(validators=[MinValueValidator(1)])
    discount_percentage = models.PositiveIntegerField(validators=[MinValueValidator(1)])
    
    def __str__(self):
        return f"{self.game_points_required} game points for {self.discount_percentage}% discount"
