from django.urls import path
from . import views

urlpatterns = [
    path('signup/', views.signup_view, name='signup'),
    path('login/', views.login_view, name='login'),
    path('menu/', views.menu_view, name='menu'),
    path('place-order/', views.place_order, name='place_order'),
    path('order-confirmation/<int:order_id>/', views.order_confirmation, name='order_confirmation'),




    # ... your existing url patterns ...
    path('feedback/', views.feedback_list, name='feedback_list'),
    path('feedback/submit/<int:item_id>/', views.submit_feedback, name='submit_feedback'),



    path('orders/', views.order_list, name='order_list'),
    path('orders/<int:order_id>/update/', views.update_order_status, name='update_order_status'),



#    # ... your existing URL patterns ...
#    path('start-game/<int:order_id>/', views.start_guessing_game, name='start_guessing_game'),
#    path('guess/<int:game_id>/', views.guess_number, name='guess_number'),

#    # ... other url patterns ...
#    path('start-game/<int:order_id>/', views.start_guessing_game, name='start_guessing_game'),
    path('game_point_redemption/', views.game_point_redemption, name='game_point_redemption'),




    path('start-game/<int:order_id>/', views.start_guessing_game, name='start_guessing_game'),
    path('play-game/<int:game_id>/', views.play_guessing_game, name='play_guessing_game'),
    path('order-history/', views.order_history, name='order_history'),
    path('rewards/', views.user_rewards, name='user_rewards'),
    path('apply-coupon/<int:order_id>/<int:coupon_id>/', views.apply_coupon, name='apply_coupon'),
    
    
    
    
]