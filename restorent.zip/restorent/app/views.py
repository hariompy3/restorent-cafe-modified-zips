from django.shortcuts import render, redirect
from django.contrib.auth import login, authenticate
from django.contrib.auth.decorators import login_required
from .models import CustomUser, Customer, MenuItem, Order, OrderItem
from django.db import transaction

def signup_view(request):
    if request.method == 'POST':
        username = request.POST['username']
        email = request.POST['email']
        password = request.POST['password']
        phone_number = request.POST['phone_number']
        address = request.POST['address']

        with transaction.atomic():
            user = CustomUser.objects.create_user(username=username, email=email, password=password, role='customer', phone_number=phone_number)
            Customer.objects.create(user=user, address=address)

        login(request, user)
        return redirect('menu')
    return render(request, 'signup.html')

def login_view(request):
    if request.method == 'POST':
        username = request.POST['username'].lower()
        password = request.POST['password'].lower()
        user = authenticate(request, username=username, password=password)
        if user is not None and user.role == 'customer':
            login(request, user)
            return redirect('menu')
        else:
            return render(request, 'login.html', {'error': 'Invalid credentials or not a customer'})
    return render(request, 'login.html')

# In views.py

@login_required
def menu_view(request):
    menu_items = MenuItem.objects.filter(is_available=True)
    coupons = Coupon.objects.filter(customer=request.user.customer_profile, is_used=False)
    return render(request, 'menu.html', {'menu_items': menu_items, 'coupons': coupons})

#@login_required
#def place_order(request):
#    if request.method == 'POST':
#        selected_items = request.POST.getlist('menu_items')
#        if not selected_items:
#            return redirect('menu')

#        with transaction.atomic():
#            order = Order.objects.create(
#                customer=request.user.customer_profile,
#                total_amount=0
#            )
#            total = 0
#            for item_id in selected_items:
#                menu_item = MenuItem.objects.get(id=item_id)
#                quantity = int(request.POST.get(f'quantity_{item_id}', 1))
#                subtotal = menu_item.price * quantity
#                OrderItem.objects.create(
#                    order=order,
#                    menu_item=menu_item,
#                    quantity=quantity,
#                    subtotal=subtotal
#                )
#                total += subtotal
#            order.total_amount = total
#            order.save()

#        return redirect('order_confirmation', order_id=order.id)
#    return redirect('menu')

@login_required
def order_confirmation(request, order_id):
    try:
        order = Order.objects.get(id=order_id, customer=request.user.customer_profile)
    except Order.DoesNotExist:
        return redirect('menu')
    return render(request, 'order_confirmation.html', {'order': order})


# Create a new file named views.py in your restaurant app directory

from django.shortcuts import render, redirect, get_object_or_404
from django.contrib.auth.decorators import login_required
from .models import MenuItem, Feedback, Customer
from django.db.models import Exists, OuterRef

@login_required
def feedback_list(request):
    customer = get_object_or_404(Customer, user=request.user)
    
    # Get all menu items that haven't been rated by the current user
    unrated_items = MenuItem.objects.filter(
        ~Exists(Feedback.objects.filter(customer=customer, menu_item=OuterRef('pk')))
    )

    context = {
        'unrated_items': unrated_items,
    }
    return render(request, 'feedback_list.html', context)

@login_required
def submit_feedback(request, item_id):
    if request.method == 'POST':
        customer = get_object_or_404(Customer, user=request.user)
        menu_item = get_object_or_404(MenuItem, id=item_id)
        rating = request.POST.get('rating')
        comment = request.POST.get('comment', '')

        Feedback.objects.create(
            customer=customer,
            menu_item=menu_item,
            rating=rating,
            comment=comment
        )

        return redirect('feedback_list')

    return redirect('feedback_list')
    
    
    

    
# restaurant/views.py
from django.shortcuts import render, get_object_or_404, redirect
from django.contrib.auth.decorators import login_required, user_passes_test
from .models import Order, Worker

def is_worker(user):
    return user.role == 'worker'


def order_list(request):
    pending_orders = Order.objects.exclude(status__in=['delivered', 'cancelled']).order_by('created_at')
    return render(request, 'order_list.html', {'orders': pending_orders})


def update_order_status(request, order_id):
    order = get_object_or_404(Order, id=order_id)
    if order.status == 'pending':
        order.status = 'preparing'
    elif order.status == 'preparing':
        order.status = 'ready'
    order.save()
    return redirect('order_list')            
    
    
    

    
#        
#            
#from django.shortcuts import render, redirect
#from django.contrib.auth.decorators import login_required
#from django.contrib import messages
#from .models import Order, GuessingGame, Coupon, Customer
#import random

#@login_required
#def start_guessing_game(request, order_id):
#    try:
#        order = Order.objects.get(id=order_id, customer=request.user.customer_profile)
#    except Order.DoesNotExist:
#        messages.error(request, "Order not found.")
#        return redirect('order_history')

#    if hasattr(order, 'guessing_game'):
#        messages.info(request, "You've already played the guessing game for this order.")
#        return redirect('guess_number', game_id=order.guessing_game.id)

#    secret_number = random.randint(1, 7)
#    game = GuessingGame.objects.create(customer=request.user.customer_profile, order=order, secret_number=secret_number)
#    print(secret_number)

#    return redirect('guess_number', game_id=game.id)

#@login_required
#def guess_number(request, game_id):
#    try:
#        game = GuessingGame.objects.get(id=game_id, customer=request.user.customer_profile)
#    except GuessingGame.DoesNotExist:
#        messages.error(request, "Game not found.")
#        return redirect('order_history')

#    if game.is_completed:
#        messages.info(request, "This game has already been completed.")
#        return redirect('order_history')

#    if request.method == 'POST':
#        guess = int(request.POST.get('guess', 0))
#        diff = abs(guess - game.secret_number)

#        if diff == 0:
#            Coupon.create_coupon(request.user.customer_profile, 50)
#            messages.success(request, "Congratulations! You guessed the correct number and won a 50% discount coupon!")
#            game.is_completed = True
#            game.save()
#        elif diff <= 3:
#            request.user.customer_profile.add_game_points(10)
#            messages.success(request, "Close guess! You earned 10 game points.")
#        elif diff <= 5:
#            request.user.customer_profile.add_game_points(5)
#            messages.success(request, "Nice try! You earned 5 game points.")
#        else:
#            messages.info(request, "Not quite. Try again!")

#        if diff <= 5:
#            game.is_completed = True
#            game.save()
#            return redirect('order_history')

#    return render(request, 'guess_number.html', {'game': game})  
#    print(guess)          
#    
#            
#                    
                            
#                                    
#from django.shortcuts import render, redirect
#from django.contrib.auth.decorators import login_required
#from django.contrib import messages
#from .models import Order, GuessingGame, Coupon
#import random

#@login_required
#def start_guessing_game(request, order_id):
#    try:
#        order = Order.objects.get(id=order_id, customer=request.user.customer_profile)
#    except Order.DoesNotExist:
#        messages.error(request, "Order not found.")
#        return redirect('order_history')

#    game, created = GuessingGame.objects.get_or_create(
#        customer=request.user.customer_profile,
#        order=order
#    )

#    if not created and game.is_played:
#        messages.info(request, "You've already played the guessing game for this order.")
#        return redirect('menu')

#    return redirect('play_guessing_game', game_id=game.id)

#@login_required
#def play_guessing_game(request, game_id):
#    try:
#        game = GuessingGame.objects.get(id=game_id, customer=request.user.customer_profile)
#    except GuessingGame.DoesNotExist:
#        messages.error(request, "Game not found.")
#        return redirect('menu')

#    if game.is_played:
#        messages.info(request, "You've already played this game.")
#        return redirect('menu')

#    if request.method == 'POST':
#        user_guess = int(request.POST.get('guess', 0))
#        secret_number = random.randint(1, 100)

#        if user_guess == secret_number:
#            Coupon.objects.create(customer=request.user.customer_profile)
#            messages.success(request, "Congratulations! You guessed the correct number and won a 50% discount coupon!")
#        elif abs(user_guess - secret_number) <= 10:
#            request.user.customer_profile.add_game_points(10)
#            messages.success(request, "Close guess! You earned 10 points.")
#        else:
#            messages.info(request, "Not quite. Better luck next time!")

#        game.is_played = True
#        game.save()

#        return redirect('menu')

#    return render(request, 'play_guessing_game.html', {'game': game }) 
#    
     
      
        
from django.shortcuts import render, redirect
from django.contrib.auth.decorators import login_required
from django.contrib import messages
from django.http import JsonResponse
from django.views.decorators.http import require_POST
from .models import Order, GuessingGame, Coupon, Customer
import random
from django.utils import timezone
@login_required
def start_guessing_game(request, order_id):
    try:
        order = Order.objects.get(id=order_id, customer=request.user.customer_profile)
    except Order.DoesNotExist:
        messages.error(request, "Order not found.")
        return redirect('order_history')

    game, created = GuessingGame.objects.get_or_create(
        customer=request.user.customer_profile,
        order=order
    )

    if not created and game.is_played:
        messages.info(request, "You've already played the guessing game for this order.")
        return redirect('order_history')

    return render(request, 'play_guessing_game.html', {'game': game})

@login_required
@require_POST
def play_guessing_game(request, game_id):
    try:
        game = GuessingGame.objects.get(id=game_id, customer=request.user.customer_profile)
    except GuessingGame.DoesNotExist:
        return JsonResponse({"error": "Game not found."}, status=404)

    if game.is_played:
        return JsonResponse({"error": "You've already played this game."}, status=400)

    try:
        user_guess = int(request.POST.get('guess', 0))
        if user_guess < 1 or user_guess > 100:
            raise ValueError("Guess must be between 1 and 100")
    except ValueError as e:
        return JsonResponse({"error": str(e)}, status=400)

    secret_number = 1

    result = {
        "user_guess": user_guess,
        "secret_number": secret_number,
        "message": "",
        "points_earned": 0,
        "coupon_won": False
    }

    if user_guess == secret_number:
        try:
            Coupon.objects.create(
                customer=request.user.customer_profile,
                code=f"WIN{random.randint(1000, 9999)}",
                discount_percentage=50,
                expiry_date=timezone.now() + timezone.timedelta(days=30)
            )
            result["message"] = "Congratulations! You guessed the correct number and won a 50% discount coupon!"
            result["coupon_won"] = True
        except Exception as e:
            result["message"] = "You won, but there was an issue creating your coupon. Please contact support."
            print(f"Error creating coupon: {str(e)}")
    elif abs(user_guess - secret_number) <= 5:
        request.user.customer_profile.add_game_points(10)
        result["message"] = "Close guess! You earned 10 points."
        result["points_earned"] = 10
    else:
        result["message"] = "Not quite. Better luck next time!"

    game.is_played = True
    game.save()

    return JsonResponse(result) 

@login_required
def order_history(request):
    # Assuming you have an OrderHistory model or you're using the Order model
    orders = Order.objects.filter(customer=request.user.customer_profile).order_by('-created_at')
    
    context = {
        'orders': orders,
        'total_points': request.user.customer_profile.game_points,
        'coupons': Coupon.objects.filter(customer=request.user.customer_profile, is_used=False)
    }
    
    return render(request, 'order_history.html', context)

# You might want to add a view to display coupons and points
@login_required
def user_rewards(request):
    customer = request.user.customer_profile
    coupons = Coupon.objects.filter(customer=customer, is_used=False)
    
    context = {
        'total_points': customer.game_points,
        'coupons': coupons
    }
    
    return render(request, 'user_rewards.html', context)

# Optional: A view to apply a coupon to an order
@login_required
def apply_coupon(request, order_id, coupon_id):
    try:
        order = Order.objects.get(id=order_id, customer=request.user.customer_profile)
        coupon = Coupon.objects.get(id=coupon_id, customer=request.user.customer_profile, is_used=False)
    except (Order.DoesNotExist, Coupon.DoesNotExist):
        messages.error(request, "Invalid order or coupon.")
        return redirect('order_history')

    # Apply the coupon logic here
    # This is a simplified example; you might want to adjust based on your specific requirements
    discount_amount = order.total_amount * (coupon.discount_percentage / 100)
    order.total_amount -= discount_amount
    order.save()

    coupon.is_used = True
    coupon.save()

    messages.success(request, f"Coupon applied successfully. You saved {discount_amount:.2f}!")
    return redirect('order_detail', order_id=order.id)               
    
                             
from decimal import Decimal
from django.db import transaction
from django.shortcuts import render, redirect
from django.contrib.auth.decorators import login_required
from .models import Order, OrderItem, MenuItem, Coupon

@login_required
def place_order(request):
    if request.method == 'POST':
        selected_items = request.POST.getlist('menu_items')
        coupon_id = request.POST.get('coupon')
        
        if not selected_items:
            return redirect('menu')

        with transaction.atomic():
            order = Order.objects.create(
                customer=request.user.customer_profile,
                total_amount=Decimal('0.00')
            )
            
            total = Decimal('0.00')
            for item_id in selected_items:
                menu_item = MenuItem.objects.get(id=item_id)
                quantity = int(request.POST.get(f'quantity_{item_id}', 1))
                subtotal = menu_item.discounted_price() * quantity
                OrderItem.objects.create(
                    order=order,
                    menu_item=menu_item,
                    quantity=quantity,
                    subtotal=subtotal
                )
                total += subtotal
            
            # Apply coupon discount if selected
            if coupon_id:
                try:
                    coupon = Coupon.objects.get(id=coupon_id, customer=request.user.customer_profile, is_used=False)
                    discount = total * (Decimal(coupon.discount_percentage) / Decimal('100'))
                    total -= discount
                    coupon.is_used = True
                    coupon.save()
                    order.applied_coupon = coupon
                except Coupon.DoesNotExist:
                    pass  # Handle invalid coupon gracefully
            
            order.total_amount = total
            order.save()

        return redirect('order_confirmation', order_id=order.id)
    return redirect('menu')         
    
# views.py
from django.shortcuts import render, redirect
from django.contrib.auth.decorators import login_required
from django.contrib import messages
from .models import Customer, PointRedemptionOption, Coupon

@login_required
def game_point_redemption(request):
    customer = request.user.customer_profile
    redemption_options = PointRedemptionOption.objects.all().order_by('game_points_required')

    if request.method == 'POST':
        option_id = request.POST.get('option_id')
        try:
            option = PointRedemptionOption.objects.get(id=option_id)
            if customer.redeem_game_points(option.game_points_required):
                coupon = Coupon.create_coupon(
                    customer=customer,
                    discount_percentage=option.discount_percentage,
                    redeemed_game_points=option.game_points_required
                )
                messages.success(request, f"Successfully redeemed {option.game_points_required} game points for a {option.discount_percentage}% discount coupon.")
            else:
                messages.error(request, "Not enough game points to redeem this offer.")
        except PointRedemptionOption.DoesNotExist:
            messages.error(request, "Invalid redemption option selected.")

        return redirect('game_point_redemption')

    context = {
        'customer': customer,
        'redemption_options': redemption_options,
    }
    return render(request, 'game_point_redemption.html', context)                                                                                                        